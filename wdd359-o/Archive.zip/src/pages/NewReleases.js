import React from 'react'
import Youtube from './../components/youtube';
function NewReleases(){
  return(
    <div>
      <Youtube />
    </div>
  );
}
export default NewReleases
